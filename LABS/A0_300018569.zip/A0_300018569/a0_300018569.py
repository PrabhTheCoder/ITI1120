print("Printing from a file.")
